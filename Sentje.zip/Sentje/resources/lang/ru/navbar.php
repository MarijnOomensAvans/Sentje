<?php

return [
    'appname' => 'Копек',
    'settings' => 'Настройки',
    'logout' => 'Выход'
];