<?php

return [
    'overview'       => 'Обзор',
    'accounts' => 'Ваши аккаунты:',
    'balance' => 'Остаток',
    'createacc' => 'Создать банковский счет',
    'edit' => 'Редактировать',
    'delete' => 'Удалить',
    'name' => 'Имя',
    'create' => 'Создать',
    'save' => 'Сохранить',
    'accbalance' => 'Остаток на счете:',
    'transactions' => 'Транзакции:',
    'transaction' => 'Транзакция',
    'reciver' => 'Получить',
    'amount' => 'Количество',
    'wcurrency' => 'Валюта',
    'description' => 'Описание',
    'status' => 'Статус',
    'type' => 'Тип'
];
