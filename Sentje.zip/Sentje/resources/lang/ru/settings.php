<?php

return [
    'settings' => 'Настройки',
    'language' => 'Язык',
    'english' => 'английский',
    'russian' => 'русский',
    'cancel' => 'Отмена',
    'save' => 'Сохранить'
];