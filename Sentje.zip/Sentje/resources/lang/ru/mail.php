<?php

return [
    'hello' => 'Здравствуйте',
    'paymentrequest' => 'Я сделал запрос на оплату за тебя.',
    'pay' => 'Оплатить',
    'thanks' => 'Спасибо',
    'description' => 'Описание',
    'amount' => 'Сумма',
    'subject' => 'Запрос на оплату'
];
