<?php

return [
    'appname' => 'Sentje',
    'settings' => 'Settings',
    'logout' => 'Logout'
];
