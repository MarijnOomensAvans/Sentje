<?php

return [
    'email'       => 'Email',
    'remember' => 'Remeber me:',
    'register' => 'Register',
    'login' => 'Login',
    'name' => 'Name',
    'emailadr' => 'E-mail Address',
    'password' => 'Password',
    'confirmpw' => 'Confirm Password'
];