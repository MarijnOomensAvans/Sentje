<?php

return [
    'settings' => 'Settings',
    'language' => 'Language',
    'english' => 'English',
    'russian' => 'Russian',
    'cancel' => 'Cancel',
    'save' => 'Save'
];