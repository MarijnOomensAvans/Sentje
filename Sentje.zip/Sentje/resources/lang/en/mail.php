<?php

return [
    'hello' => 'Hello',
    'paymentrequest' => 'I have made a payment request for you.',
    'pay' => 'Pay',
    'thanks' => 'Thanks',
    'description' => 'Description',
    'amount' => 'Amount',
    'subject' => 'Payment request'
];
