<?php

return [
    'welcome'       => 'Welcome to our application'
];
