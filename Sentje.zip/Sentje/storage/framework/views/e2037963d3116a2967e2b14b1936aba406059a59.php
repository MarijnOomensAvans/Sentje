<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header"><?php echo e(__('content.overview')); ?></div>
                <div class="card-body">
                    <h1><?php echo e(__('content.accounts')); ?></h1>
                    <table class="table">
                        <thead>
                        <tr>
                            <th scope="col"><?php echo e(__('account.name')); ?></th>
                            <th scope="col"><?php echo e(__('content.balance')); ?></th>
                            <th scope="col"><a href="<?php echo e(url('bankaccounts/create')); ?>"><button type="button" class="btn btn-success"><i class="fa fa-fw fa-plus mr-1"></i><?php echo e(__('content.createacc')); ?></button></a></th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php $__currentLoopData = Auth::user()->bankAccounts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $account): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><a href="bankaccounts/<?php echo e($account->id); ?>"><?php echo e(\Illuminate\Support\Facades\Crypt::decrypt($account->name)); ?></a></td>
                                <td><?php echo e($account->balance()); ?> €</td>
                                <td>
                                    <div class="input-group mb-3">
                                    <a href="/bankaccounts/<?php echo e($account->id); ?>/edit"><button type="button" class="btn btn-primary"><i class="fa fa-pencil-alt"></i> <?php echo e(__('content.edit')); ?></button></a> <form method="POST" action="/bankaccounts/<?php echo e($account->id); ?>" style="width: 30%;" class="form-inline"><?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?><button type="submit" class="btn btn-danger"><i class="fa fa-times"></i> <?php echo e(__('content.delete')); ?></button></form>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Marijn\Documents\Github\Sentje\Sentje\resources\views/home.blade.php ENDPATH**/ ?>