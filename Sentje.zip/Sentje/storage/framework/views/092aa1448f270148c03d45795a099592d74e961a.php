<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card">
                    <div class="card-header"><?php echo e(__('content.transaction')); ?></div>

                    <div class="card-body">
                        <div class="row">
                            <div class="col-lg-3"><b><?php echo e(__('content.reciever')); ?>: </b></div>
                            <div class="col-lg-9"><?php echo e(\Illuminate\Support\Facades\Crypt::decrypt(Auth::user()->name)); ?></div>
                        </div>
                        <hr>
                        <?php if(!empty($transaction->email)): ?>
                        <div class="row">
                            <div class="col-lg-3"><b><?php echo e(__('content.email')); ?>: </b></div>
                            <div class="col-lg-9"><?php echo e($transaction->email); ?></div>
                        </div>
                        <hr>
                        <?php endif; ?>
                        <div class="row">
                            <div class="col-lg-3"><b><?php echo e(__('content.amount')); ?>: </b></div>
                            <div class="col-lg-9"><?php echo e($transaction->amount); ?> <?php if($transaction->currency == 'EUR'): ?>€<?php else: ?>₽<?php endif; ?></div>
                        </div>
                        <hr>
                        <div class="row">
                            <div class="col-lg-3"><b><?php echo e(__('content.wcurrency')); ?>: </b></div>
                            <div class="col-lg-9"><?php echo e($transaction->currency); ?></div>
                        </div>
                        <hr>
                        <div class="row">
                            <div class="col-lg-3"><b><?php echo e(__('content.description')); ?>: </b></div>
                            <div class="col-lg-9"><?php echo e($transaction->description); ?></div>
                        </div>
                        <hr>
                        <div class="row">
                            <div class="col-lg-3"><b><?php echo e(__('content.type')); ?>: </b></div>
                            <div class="col-lg-9"><?php echo e($transaction->type); ?></div>
                        </div>
                        <hr>
                        <div class="row">
                            <div class="col-lg-3"><b><?php echo e(__('content.status')); ?>: </b></div>
                            <div class="col-lg-9"><?php echo e($transaction->status); ?></div>
                        </div>
                        <?php if($transaction->getPaymentAttribute()->isPaid()): ?>
                        <hr>
                        <div class="row">
                            <div class="col-lg-3"><b><?php echo e(__('content.paidat')); ?>: </b></div>
                            <div class="col-lg-9"><?php echo e($transaction->paid_at); ?></div>
                        </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Marijn\Documents\Github\Sentje\Sentje\resources\views/transaction/showtransaction.blade.php ENDPATH**/ ?>