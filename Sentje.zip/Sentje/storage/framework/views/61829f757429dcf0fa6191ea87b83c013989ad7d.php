<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card">
                    <div class="card-header"><?php echo e(__('content.donation')); ?></div>
                    <div class="card-body">
                        <form method="POST" action="/transactions">
                            <?php echo csrf_field(); ?>
                            <input type="hidden" name="type" value="Donation">
                            <input type="hidden" name="status" value="Unpaid">
                            <input type="hidden" name="bank_account_id" value="<?php echo e($accountid); ?>">
                            <div class="form-group">
                                <label>Amount</label>
                                <input type="number" min="0.01" step="0.01" class="form-control" aria-describedby="amountHelp" placeholder="<?php echo e(__('content.amount')); ?>" name="amount" required>
                            </div>
                            <hr>
                            <div class="form-group">
                                <label>Currency</label>
                                <select class="form-control " name="currency">
                                    <option value="EUR" selected>Euro : €</option>
                                    <option value="RUB">Ruble : ₽</option>
                                </select>
                            </div>
                            <hr>
                            <div class="form-group">
                                <label>Description</label>
                                <textarea class="form-control " name="description" rows="4"></textarea>
                            </div>
                            <hr>
                            <div class="form-group row mb-0">
                                <div class="col-12 text-left">
                                    <button type="submit" class="btn btn-success">Create donation</button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Marijn\Documents\Github\Sentje\Sentje\resources\views/transaction/createdonation.blade.php ENDPATH**/ ?>