<?php $__env->startSection('content'); ?>
    <div class="container">
        <form method="POST" action="/bankaccounts">
            <?php echo csrf_field(); ?>
            <div class="form-group">
                <label for="name"><?php echo e(__('content.name')); ?></label>
                <input type="text" class="form-control" id="name" aria-describedby="nameHelp" placeholder="<?php echo e(__('content.name')); ?>" name="name" required>
            </div>

            <?php if($errors->any()): ?>
                <div>
                    <ul>
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            <?php endif; ?>

            <button type="submit" class="btn btn-primary"><?php echo e(__('create')); ?></button>
        </form>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Marijn\Documents\Github\Sentje\Sentje\resources\views/bankaccount/createbankaccount.blade.php ENDPATH**/ ?>