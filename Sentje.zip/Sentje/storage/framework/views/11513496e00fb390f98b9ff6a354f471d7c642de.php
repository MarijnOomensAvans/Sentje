<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <?php if($success): ?>
                    <h1>Hartelijk dank dat u gekozen hebt om VEADS te helpen met uw donatie!<br/>VEADS heeft uw donatie in goede orde ontvangen.</h1>
                <?php elseif($pending): ?>
                    <h1>Hartelijk dank dat u gekozen hebt om VEADS te helpen met uw donatie!<br/>Uw donatie wordt momenteel verwerkt.</h1>
                <?php else: ?>
                    <h1>Hartelijk dank dat u gekozen hebt om VEADS te helpen met uw donatie!<br/>Er is een fout opgetreden tijdens het verwerken van uw donatie. Probeer het later nog een keer.</h1>
                <?php endif; ?>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Marijn\Documents\Github\Sentje\Sentje\resources\views/transaction/thanks.blade.php ENDPATH**/ ?>