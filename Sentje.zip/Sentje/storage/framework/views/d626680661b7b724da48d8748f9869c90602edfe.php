<?php echo e($slot); ?>

<?php /**PATH C:\Users\Marijn\Documents\Github\Sentje\Sentje\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>