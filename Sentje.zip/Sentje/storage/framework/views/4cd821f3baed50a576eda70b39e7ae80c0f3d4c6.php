<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card">
                    <div class="card-header"><?php echo e(\Illuminate\Support\Facades\Crypt::decrypt($bankaccount->name)); ?></div>

                    <div class="card-body">
                        <h4><?php echo e(__('content.accbalance')); ?> <?php echo e($bankaccount->balance()); ?> €</h4>
                        <p><?php echo e(__('content.donationlink')); ?>: <a href="<?php echo e(url('/donate/' . $bankaccount->id)); ?>"><?php echo e(url('/donate/' . $bankaccount->id)); ?></a> </p>
                        <h1><?php echo e(__('content.transactions')); ?></h1>
                        
                        <table class="table">
                            <thead>
                            <tr>
                                <th scope="col"><?php echo e(__('content.reciever')); ?></th>
                                <th scope="col"><?php echo e(__('content.amount')); ?></th>
                                <th scope="col"><?php echo e(__('content.type')); ?></th>
                                <th scope="col"><?php echo e(__('content.status')); ?></th>
                                <th><a href="/transactions/create/<?php echo e($bankaccount->id); ?>"><button type="button" class="btn btn-success"><i class="fa fa-fw fa-plus mr-1"></i> Create payment request</button></a></th>
                            </tr>
                            </thead>
                            <tbody>
                            <?php $__currentLoopData = $bankaccount->transactions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $transaction): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                <div>
                                    <td><?php echo e(\Illuminate\Support\Facades\Crypt::decrypt(Auth::user()->name)); ?></td>
                                    <td><?php echo e($transaction->amount); ?> <?php if($transaction->currency == 'EUR'): ?>€<?php else: ?>₽<?php endif; ?></td>
                                    <td><?php echo e($transaction->type); ?></td>
                                    <td><?php echo e($transaction->status); ?></td>
                                    <td>
                                        <div class="input-group mb-3">
                                            <a href="/transactions/<?php echo e($transaction->id); ?>"><button class="btn-primary btn"><i class="fa fa-eye"></i> View</button></a>
                                            <?php if($transaction->type == 'Request' && $transaction->status != 'Paid'): ?>
                                            <button class="btn-secondary btn"><i class="fa fa-eye"></i> Edit</button>
                                            <?php endif; ?>
                                            <?php if($transaction->status != 'Paid'): ?>
                                                <form method="POST" action="/transactions/<?php echo e($transaction->id); ?>">
                                                    <?php echo csrf_field(); ?>
                                                    <?php echo method_field('DELETE'); ?>
                                            <button type="submit" class="btn-danger btn"><i class="fa fa-times"></i> Delete</button>
                                                </form>
                                            <?php endif; ?>
                                        </div>
                                </div>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Marijn\Documents\Github\Sentje\Sentje\resources\views/bankaccount/showbankaccount.blade.php ENDPATH**/ ?>