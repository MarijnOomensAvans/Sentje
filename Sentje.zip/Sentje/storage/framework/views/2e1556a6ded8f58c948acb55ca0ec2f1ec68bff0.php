<?php $__env->startComponent('mail::message'); ?>
<h1><?php echo e(__('mail.hello')); ?> <?php echo e($transaction->name); ?></h1>

<h3><?php echo e(__('mail.paymentrequest')); ?></h3>

<b><?php echo e(__('mail.description')); ?>:</b><p><?php echo e($transaction->description); ?></p>

<b><?php echo e(__('mail.amount')); ?>:</b><p><?php echo e($transaction->amount); ?> <?php if($transaction->currency == 'EUR'): ?>€<?php else: ?>₽<?php endif; ?></p>

<?php $__env->startComponent('mail::button', ['url' => url('/pay/' . $transaction->id)]); ?>
    <?php echo e(__('mail.pay')); ?>

<?php echo $__env->renderComponent(); ?>

<?php echo e(__('mail.thanks')); ?>,<br>
<?php echo e(Auth::user()->name); ?>

<?php echo $__env->renderComponent(); ?>
<?php /**PATH C:\Users\Marijn\Documents\Github\Sentje\Sentje\resources\views/emails/transaction-created.blade.php ENDPATH**/ ?>