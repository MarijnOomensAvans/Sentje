<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card">
                    <div class="card-header"><?php echo e(__('settings.settings')); ?></div>
                    <div class="card-body">
                        <form method="POST" action="/settings">
                            <?php echo csrf_field(); ?>
                        <div class="form-group row mb-4">
                            <label class="col-sm-4 col-lg-3 col-form-label"><?php echo e(__('settings.language')); ?></label>
                            <div class="col-sm-8 col-lg-9">
                                <select class="form-control " name="language">
                                    <option value="en" <?php echo e((app()->getLocale() == 'en') ? 'selected' : ''); ?>><?php echo e(__('settings.english')); ?></option>
                                    <option value="ru" <?php echo e((app()->getLocale() == 'ru') ? 'selected' : ''); ?>><?php echo e(__('settings.russian')); ?></option>
                                </select>

                            </div>
                        </div>

                        <div class="form-group row mb-0">
                            <div class="col-12 text-left">
                                <a href="<?php echo e(route('home')); ?>" class="btn btn-warning"><?php echo e(__('settings.cancel')); ?></a>
                                <button type="submit" class="btn btn-primary"><?php echo e(__('settings.save')); ?></button>
                            </div>
                        </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
        </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Marijn\Documents\Github\Sentje\Sentje\resources\views/usersettings.blade.php ENDPATH**/ ?>