<?php $__env->startSection('content'); ?>
<div id="loginform">
    <form method="POST" action="<?php echo e(route('login')); ?>">
        <?php echo csrf_field(); ?>
        <img src="<?php echo e(asset('images/logo.png')); ?>" class="logo">
        <input id="email" name="email" type="email" class="input" value="<?php echo e(old('email')); ?>" placeholder="<?php echo e(__('account.email')); ?>" required autocomplete="email" autofocus>
        <input id="password" name="password" type="password" class="input" placeholder="<?php echo e(__('account.password')); ?>" required autocomplete="current-password">
        <label><?php echo e(__('account.remember')); ?></label>
        <input type="checkbox" class="checkbox" name="remember" id="remember" <?php echo e(old('remember') ? 'checked' : ''); ?>>
        <a href="<?php echo e(route('register')); ?>" class="register"><?php echo e(__('account.register')); ?></a>
        <div class="loginbutton"><button type="submit" ><?php echo e(__('account.login')); ?></button></div>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('styles'); ?>
    <link href="<?php echo e(asset('css/login.css')); ?>" rel="stylesheet">
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Marijn\Documents\Github\Sentje\Sentje\resources\views/auth/login.blade.php ENDPATH**/ ?>