<?php

/* @var $factory \Illuminate\Database\Eloquent\Factory */

use Sentje\BankAccount;
use Faker\Generator as Faker;

$factory->define(BankAccount::class, function (Faker $faker) {
    return [
        //
    ];
});
